﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2KiranP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string class1, class2, class3, class4;

                class1 = textBox1.Text;
                class2 = textBox2.Text;
                class3 = textBox3.Text;
                class4 = textBox4.Text;

                double RA,HA, LA, WA, P,  VAS, VAC, VAR;

                RA = double.Parse(class1);
                HA = double.Parse(class2);
                LA = double.Parse(class3);
                WA = double.Parse(class4);


                P = 3.14159;


                VAS = (4.0 / 3) * P * RA * RA * RA;

                VAC = (P) * (RA * RA) * (HA);

                VAR = LA * WA * HA;

                if (radioButton1.Checked)
                {
                    label6.Text = VAS.ToString();
                    textBox2.Text = ("");
                    textBox3.Text = ("");
                    textBox4.Text = ("");
                }
                else if (radioButton2.Checked)
                {
                    label6.Text = VAC.ToString();
                    textBox3.Text = ("");
                    textBox4.Text = ("");

                }
                else if (radioButton3.Checked)
                {
                    label6.Text = VAR.ToString();
                    textBox1.Text = ("");
                }

            }
            catch
            {
                MessageBox.Show("ENTER THE VALUES");
            }






        }

    }
    }


